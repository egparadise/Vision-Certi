@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-VisionCertiBridge.ps1"
if errorlevel 1 (
  echo Installation failed. Check the message above.
) else (
  echo Installation complete. Return to the certificate page and click retry.
)
pause
